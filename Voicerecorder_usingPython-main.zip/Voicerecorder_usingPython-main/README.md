# Voicerecorder_usingPython
The objective of this project is to design and develop a voice recorder application in Python that allows users to record audio using their device's microphone, save the recordings, and manage them. The application should provide an intuitive user interface and reliable audio recording capabilities
